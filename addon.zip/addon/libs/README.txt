The BBS FS jar (bbs-2.7-1.20.1) is already in this folder so the project builds out of the box.
Only keep ONE BBS jar in here. If you update BBS, replace the jar.
