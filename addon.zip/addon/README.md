# BBS Model Block Particles

A client-side Fabric addon for **BBS FS 2.7** on **Minecraft 1.20.1**.

When a Model Block is **placed** or **broken**, it spawns block-style particles
(same shape, speed and gravity as normal block-break particles) whose colors come
from the form inside the Model Block:

- Model / Billboard / Extruded forms: colors are sampled from the form's real
  texture and multiplied by the form's color. A pure blue form gives blue particles.
  `color:rrggbb` texture links work too.
- Block forms: the vanilla block's own particle texture is used.
- Mining in survival also throws the little crack particles off the face you hit.
- Works for other players' placing and breaking too, not only your own.

If a Model Block has no form (or only forms without a color, like particle forms),
nothing extra is spawned and vanilla behavior is left alone.

## Install

Drop the jar from `build/libs/` into your `mods` folder next to BBS FS 2.7-1.20.1
and Fabric API (0.92.2 or newer for 1.20.1).

## Build

1. `libs/` already contains `bbs-2.7-1.20.1.jar` (keep only one BBS jar there).
2. `./gradlew build` (or `./gradlew runClient` to test).
3. The jar lands in `build/libs/`.

## Tweaking

`ModelBlockParticles.java` has the particle counts at the top
(`BREAK_PER_AXIS = 4` means 4x4x4 = 64 particles, `PLACE_PER_AXIS = 3` means 27).

## Layout

```
FormPalette.java                reads texture + color from a BBS form
ModelBlockParticles.java        spawns the particles, queues place bursts
mixin/ParticleManagerMixin      replaces break + mining particles for Model Blocks
mixin/BlockItemPlaceMixin       detects your own placement
mixin/ClientPlayNetworkHandlerMixin   detects other players' placement
```
