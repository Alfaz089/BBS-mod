package com.example.bbsmodelparticles.mixin;

import com.example.bbsmodelparticles.ModelBlockParticles;
import mchorse.bbs_mod.blocks.ModelBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Vanilla builds block particles from the block's model texture. A Model Block has
 * none, so we swap in particles colored from the form instead.
 */
@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin
{
    /** Block broken (all players): the burst of particles. */
    @Inject(method = "addBlockBreakParticles", at = @At("HEAD"), cancellable = true)
    private void bbsModelParticles$break(BlockPos pos, BlockState state, CallbackInfo info)
    {
        if (state.getBlock() instanceof ModelBlock && ModelBlockParticles.spawnBreak(pos))
        {
            info.cancel();
        }
    }

    /** Block being mined: the single particles that fly off the face. */
    @Inject(method = "addBlockBreakingParticles", at = @At("HEAD"), cancellable = true)
    private void bbsModelParticles$crack(BlockPos pos, Direction direction, CallbackInfo info)
    {
        ClientWorld world = MinecraftClient.getInstance().world;

        if (world != null && world.getBlockState(pos).getBlock() instanceof ModelBlock && ModelBlockParticles.spawnCrack(pos, direction))
        {
            info.cancel();
        }
    }
}
