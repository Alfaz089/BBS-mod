package com.example.bbsmodelparticles.mixin;

import com.example.bbsmodelparticles.ModelBlockParticles;
import mchorse.bbs_mod.blocks.ModelBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.util.ActionResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** You placed a Model Block: queue the place particles (fired once its form arrives). */
@Mixin(BlockItem.class)
public abstract class BlockItemPlaceMixin
{
    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At("RETURN"))
    private void bbsModelParticles$place(ItemPlacementContext context, CallbackInfoReturnable<ActionResult> info)
    {
        BlockItem self = (BlockItem) (Object) this;

        if (context.getWorld().isClient() && self.getBlock() instanceof ModelBlock && info.getReturnValue().isAccepted())
        {
            ModelBlockParticles.queuePlace(context.getBlockPos());
        }
    }
}
