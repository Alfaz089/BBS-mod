package com.example.bbsmodelparticles;

import mchorse.bbs_mod.blocks.ModelBlock;
import mchorse.bbs_mod.blocks.entities.ModelBlockEntity;
import mchorse.bbs_mod.forms.forms.BlockForm;
import mchorse.bbs_mod.forms.forms.BodyPart;
import mchorse.bbs_mod.forms.forms.Form;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Spawns vanilla block-style particles for BBS Model Blocks. The particles look and
 * move exactly like normal block-break particles, but their color comes from the
 * form's texture and color instead of from a block model (a Model Block has none).
 */
public final class ModelBlockParticles
{
    /** Particles per axis when breaking (vanilla uses 4, so 64 particles). */
    private static final int BREAK_PER_AXIS = 4;
    /** Particles per axis when placing (27 particles). */
    private static final int PLACE_PER_AXIS = 3;
    /** How long (ticks) to wait for the server to send the form before giving up. */
    private static final int PENDING_TICKS = 60;

    private static final Map<BlockPos, Integer> PENDING = new HashMap<>();

    private ModelBlockParticles()
    {}

    /** What the particles should look like: either a vanilla block, or a color palette. */
    private static final class Source
    {
        final BlockState block;
        final float[][] palette;

        Source(BlockState block, float[][] palette)
        {
            this.block = block;
            this.palette = palette;
        }
    }

    /* ---------------------------------------------------------------- queue */

    public static void queuePlace(BlockPos pos)
    {
        PENDING.put(pos.toImmutable(), PENDING_TICKS);
    }

    public static void clear()
    {
        PENDING.clear();
    }

    public static void tick(ClientWorld world)
    {
        if (PENDING.isEmpty())
        {
            return;
        }

        Iterator<Map.Entry<BlockPos, Integer>> it = PENDING.entrySet().iterator();

        while (it.hasNext())
        {
            Map.Entry<BlockPos, Integer> entry = it.next();
            BlockPos pos = entry.getKey();
            BlockEntity be = world.getBlockEntity(pos);

            if (be instanceof ModelBlockEntity model && world.getBlockState(pos).getBlock() instanceof ModelBlock)
            {
                Form form = model.getProperties().getForm();

                if (form != null)
                {
                    /* Form data is here: fire once, whether or not it had a readable color. */
                    Source source = resolve(form, 0);

                    if (source != null)
                    {
                        burst(pos, getBox(model), source, PLACE_PER_AXIS);
                    }

                    it.remove();

                    continue;
                }
            }

            int left = entry.getValue() - 1;

            if (left <= 0)
            {
                it.remove();
            }
            else
            {
                entry.setValue(left);
            }
        }
    }

    /* ---------------------------------------------------------------- break */

    /** @return true if particles were spawned (the vanilla ones should then be skipped). */
    public static boolean spawnBreak(BlockPos pos)
    {
        ModelBlockEntity model = getModelBlockEntity(pos);

        if (model == null)
        {
            return false;
        }

        Source source = resolve(model.getProperties().getForm(), 0);

        if (source == null)
        {
            return false;
        }

        burst(pos, getBox(model), source, BREAK_PER_AXIS);

        return true;
    }

    /** The few particles that fly off the face you are mining (survival). */
    public static boolean spawnCrack(BlockPos pos, Direction side)
    {
        ModelBlockEntity model = getModelBlockEntity(pos);

        if (model == null)
        {
            return false;
        }

        Source source = resolve(model.getProperties().getForm(), 0);

        if (source == null)
        {
            return false;
        }

        Box box = getBox(model);
        Random random = Random.create();
        double x = pos.getX() + random.nextDouble() * (box.maxX - box.minX - 0.4) + 0.2 + box.minX;
        double y = pos.getY() + random.nextDouble() * (box.maxY - box.minY - 0.4) + 0.2 + box.minY;
        double z = pos.getZ() + random.nextDouble() * (box.maxZ - box.minZ - 0.4) + 0.2 + box.minZ;

        switch (side)
        {
            case DOWN -> y = pos.getY() + box.minY - 0.1;
            case UP -> y = pos.getY() + box.maxY + 0.1;
            case NORTH -> z = pos.getZ() + box.minZ - 0.1;
            case SOUTH -> z = pos.getZ() + box.maxZ + 0.1;
            case WEST -> x = pos.getX() + box.minX - 0.1;
            case EAST -> x = pos.getX() + box.maxX + 0.1;
        }

        Particle particle = spawn(source, x, y, z, 0, 0, 0);

        if (particle != null)
        {
            particle.move(0.2F);
            particle.scale(0.6F);
        }

        return true;
    }

    /* -------------------------------------------------------------- helpers */

    private static ModelBlockEntity getModelBlockEntity(BlockPos pos)
    {
        ClientWorld world = MinecraftClient.getInstance().world;

        if (world == null)
        {
            return null;
        }

        BlockEntity be = world.getBlockEntity(pos);

        return be instanceof ModelBlockEntity model ? model : null;
    }

    private static Box getBox(ModelBlockEntity model)
    {
        try
        {
            VoxelShape shape = model.getShape();

            if (shape != null && !shape.isEmpty())
            {
                return shape.getBoundingBox();
            }
        }
        catch (Throwable ignored)
        {}

        return new Box(0, 0, 0, 1, 1, 1);
    }

    /** Finds the first thing in the form tree we know how to color particles from. */
    private static Source resolve(Form form, int depth)
    {
        if (form == null || depth > 4)
        {
            return null;
        }

        try
        {
            if (!Boolean.TRUE.equals(form.visible.get()))
            {
                return null;
            }

            if (form instanceof BlockForm blockForm)
            {
                BlockState state = blockForm.blockState.get();

                if (state != null && !state.isAir())
                {
                    /* A vanilla block: reuse its real particle texture. */
                    return new Source(state, null);
                }
            }
            else if (FormPalette.isTextured(form))
            {
                float[][] palette = FormPalette.fromForm(form);

                if (palette != null)
                {
                    return new Source(null, palette);
                }
            }

            for (BodyPart part : form.parts.getAllTyped())
            {
                Source source = resolve(part.getForm(), depth + 1);

                if (source != null)
                {
                    return source;
                }
            }
        }
        catch (Throwable t)
        {
            BBSModelParticlesClient.LOGGER.debug("Could not resolve form for particles", t);
        }

        return null;
    }

    private static void burst(BlockPos pos, Box box, Source source, int perAxis)
    {
        for (int i = 0; i < perAxis; i++)
        {
            for (int j = 0; j < perAxis; j++)
            {
                for (int k = 0; k < perAxis; k++)
                {
                    double fx = (i + 0.5D) / perAxis;
                    double fy = (j + 0.5D) / perAxis;
                    double fz = (k + 0.5D) / perAxis;
                    double x = pos.getX() + box.minX + fx * (box.maxX - box.minX);
                    double y = pos.getY() + box.minY + fy * (box.maxY - box.minY);
                    double z = pos.getZ() + box.minZ + fz * (box.maxZ - box.minZ);

                    spawn(source, x, y, z, x - pos.getX() - 0.5D, y - pos.getY() - 0.5D, z - pos.getZ() - 0.5D);
                }
            }
        }
    }

    private static Particle spawn(Source source, double x, double y, double z, double vx, double vy, double vz)
    {
        ParticleManager manager = MinecraftClient.getInstance().particleManager;
        /* White concrete has a plain white texture, so tinting it gives the exact color. */
        BlockState state = source.block != null ? source.block : Blocks.WHITE_CONCRETE.getDefaultState();
        Particle particle = manager.addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, state), x, y, z, vx, vy, vz);

        if (particle != null && source.palette != null && source.palette.length > 0)
        {
            float[] color = source.palette[(int) (Math.random() * source.palette.length)];

            particle.setColor(color[0], color[1], color[2]);
        }

        return particle;
    }
}
