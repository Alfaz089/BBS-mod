package com.example.bbsmodelparticles.mixin;

import com.example.bbsmodelparticles.ModelBlockParticles;
import mchorse.bbs_mod.blocks.ModelBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Another player placed a Model Block: the server tells us with a block update. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin
{
    @Shadow
    private ClientWorld world;

    @Inject(method = "onBlockUpdate", at = @At("HEAD"))
    private void bbsModelParticles$blockUpdate(BlockUpdateS2CPacket packet, CallbackInfo info)
    {
        /* This method first runs on the network thread before being re-run on the main thread. */
        if (!MinecraftClient.getInstance().isOnThread() || this.world == null)
        {
            return;
        }

        if (packet.getState().getBlock() instanceof ModelBlock && !(this.world.getBlockState(packet.getPos()).getBlock() instanceof ModelBlock))
        {
            ModelBlockParticles.queuePlace(packet.getPos());
        }
    }
}
