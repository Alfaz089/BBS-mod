package com.example.bbsmodelparticles;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client entrypoint. Particles on break are produced by {@code ParticleManagerMixin};
 * particles on place are queued by the placement mixins and fired from the tick below
 * once the Model Block's form data has arrived from the server.
 */
public class BBSModelParticlesClient implements ClientModInitializer
{
    public static final String MOD_ID = "bbs_model_particles";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient()
    {
        ClientTickEvents.END_WORLD_TICK.register(ModelBlockParticles::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ModelBlockParticles.clear());

        LOGGER.info("[{}] BBS Model Block particles loaded", MOD_ID);
    }
}
