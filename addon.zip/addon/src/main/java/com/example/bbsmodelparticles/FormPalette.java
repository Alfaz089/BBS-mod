package com.example.bbsmodelparticles;

import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.cubic.ModelInstance;
import mchorse.bbs_mod.forms.forms.BillboardForm;
import mchorse.bbs_mod.forms.forms.ExtrudedForm;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.utils.colors.Color;
import mchorse.bbs_mod.utils.resources.Pixels;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Turns a textured BBS form (model, billboard, extruded) into a small palette of
 * RGB colors (0..1) sampled from the form's real texture and multiplied by the
 * form's color. A pure blue form gives a palette of blue only.
 *
 * This class deliberately touches only BBS types (no Minecraft types).
 */
final class FormPalette
{
    private static final int SAMPLES = 48;
    private static final int MAX_TRIES = 600;
    private static final long CACHE_MS = 5000;

    private static final Map<String, Entry> CACHE = new HashMap<>();
    private static final Random RANDOM = new Random();

    private static final class Entry
    {
        final long time = System.currentTimeMillis();
        final float[][] palette;

        Entry(float[][] palette)
        {
            this.palette = palette;
        }
    }

    private FormPalette()
    {}

    /** @return true if this form type has a texture and color this class can read. */
    static boolean isTextured(Form form)
    {
        return form instanceof ModelForm || form instanceof BillboardForm || form instanceof ExtrudedForm;
    }

    /** @return palette of RGB triples, or null if nothing could be read. */
    static float[][] fromForm(Form form)
    {
        try
        {
            Link texture = null;
            Color tint = null;

            if (form instanceof ModelForm model)
            {
                texture = model.texture.get();
                tint = model.color.get();

                if (texture == null)
                {
                    /* No texture override: the model's own default texture is used. */
                    ModelInstance instance = BBSModClient.getModels().getModel(model.model.get());

                    if (instance != null)
                    {
                        texture = instance.getTexture();
                    }
                }
            }
            else if (form instanceof BillboardForm billboard)
            {
                texture = billboard.texture.get();
                tint = billboard.color.get();
            }
            else if (form instanceof ExtrudedForm extruded)
            {
                texture = extruded.texture.get();
                tint = extruded.color.get();
            }
            else
            {
                return null;
            }

            float[][] base = texture == null ? null : fromLink(texture);

            if (base == null)
            {
                /* Untextured / unreadable: plain white times the form color. */
                base = new float[][] {{1F, 1F, 1F}};
            }

            return tinted(base, tint);
        }
        catch (Throwable t)
        {
            BBSModelParticlesClient.LOGGER.debug("Could not read form colors", t);

            return null;
        }
    }

    private static float[][] tinted(float[][] base, Color tint)
    {
        if (tint == null)
        {
            return base;
        }

        float[][] result = new float[base.length][3];

        for (int i = 0; i < base.length; i++)
        {
            result[i][0] = base[i][0] * tint.r;
            result[i][1] = base[i][1] * tint.g;
            result[i][2] = base[i][2] * tint.b;
        }

        return result;
    }

    /** Works for PNG assets and for BBS "color:rrggbb" links (pure color textures). */
    private static float[][] fromLink(Link link)
    {
        String key = link.toString();
        Entry entry = CACHE.get(key);

        if (entry != null && System.currentTimeMillis() - entry.time < CACHE_MS)
        {
            return entry.palette;
        }

        float[][] palette = null;
        Pixels pixels = null;

        try
        {
            pixels = BBSModClient.getTextures().getPixels(link);
            palette = sample(pixels);
        }
        catch (Throwable t)
        {
            BBSModelParticlesClient.LOGGER.debug("Could not read texture {}", key, t);
        }
        finally
        {
            if (pixels != null)
            {
                try
                {
                    pixels.delete();
                }
                catch (Throwable ignored)
                {}
            }
        }

        CACHE.put(key, new Entry(palette));

        return palette;
    }

    private static float[][] sample(Pixels pixels)
    {
        if (pixels == null || pixels.width <= 0 || pixels.height <= 0)
        {
            return null;
        }

        float[][] result = new float[SAMPLES][];
        int found = 0;

        for (int i = 0; i < MAX_TRIES && found < SAMPLES; i++)
        {
            int x = RANDOM.nextInt(pixels.width);
            int y = RANDOM.nextInt(pixels.height);
            Color color = pixels.getColor(x, y);

            if (color.a < 0.1F)
            {
                continue;
            }

            result[found++] = new float[] {color.r, color.g, color.b};
        }

        if (found == 0)
        {
            return null;
        }

        float[][] trimmed = new float[found][];

        System.arraycopy(result, 0, trimmed, 0, found);

        return trimmed;
    }
}
